#include <QApplication>
#include "palindrome.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    Palindrome test;
    test.show();


    return app.exec();
}
